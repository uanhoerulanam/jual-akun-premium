UAN DIGITAL STORE — WEBSITE KATALOG

ISI FOLDER
- index.html: halaman website
- assets/wink.jpg: banner WINK yang tersedia
- assets/alight-motion.jpg: banner Alight Motion yang tersedia
- assets/bstation-logo.jpg: gambar logo Bstation yang tersedia

SEBELUM DIPUBLIKASIKAN
1. Buka index.html dengan editor teks.
2. Cari 628XXXXXXXXXX dan ganti dengan nomor WhatsApp admin, format internasional tanpa + atau spasi.
3. Untuk banner utama/YouTube, tambahkan gambar ke folder assets dan sesuaikan HTML bila diperlukan.
4. Periksa harga, durasi, fitur, metode akses, dan ketentuan setiap paket agar akurat.
5. Upload seluruh isi folder (bukan hanya index.html) ke hosting statis seperti GitHub Pages.

CATATAN
- Website ini adalah template katalog statis; tidak memproses pembayaran atau menyimpan pesanan.
- Gambar yang diunggah ke Gemini belum otomatis masuk ke website. Letakkan file dengan nama yang sesuai di folder assets.
- Produk Bstation belum memiliki durasi yang ditentukan pada informasi yang tersedia, sehingga halaman meminta pelanggan mengonfirmasi durasinya.
